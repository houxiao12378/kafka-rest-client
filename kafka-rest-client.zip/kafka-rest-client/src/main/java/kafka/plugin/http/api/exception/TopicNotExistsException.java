package kafka.plugin.http.api.exception;

public class TopicNotExistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public TopicNotExistsException(String message) {
		super(message);
	}

}
