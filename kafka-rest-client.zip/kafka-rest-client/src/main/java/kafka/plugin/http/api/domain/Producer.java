package kafka.plugin.http.api.domain;

import java.util.concurrent.LinkedBlockingQueue;

public class Producer {
	private String id;
	private Long createTime;
	private Long timeout;
	private Process process;
	private LinkedBlockingQueue<String> consoleMessages = new LinkedBlockingQueue<String>();
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Long getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}
	public Long getTimeout() {
		return timeout;
	}
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}
	
	
	public Process getProcess() {
		return process;
	}
	public void setProcess(Process process) {
		this.process = process;
	}
	
	
	public LinkedBlockingQueue<String> getConsoleMessages() {
		return consoleMessages;
	}
	public void setConsoleMessages(LinkedBlockingQueue<String> consoleMessages) {
		this.consoleMessages = consoleMessages;
	}
	@Override
	public String toString() {
		return "Producer [id=" + id + ", createTime=" + createTime + ", timeout=" + timeout + ", process=" + process
				+ ", consoleMessages=" + consoleMessages + "]";
	}
	
	
	

	
	
	
	
	
	
}
