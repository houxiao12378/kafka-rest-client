package kafka.plugin.http.api.util;

import com.google.common.base.Strings;

public class StringUtil {
	public static String joinPath(String... paths) {
		StringBuilder sb = new StringBuilder();

		for (String path : paths) {
			path = path.startsWith("/") ? path.substring(1) : path;
			path = path.endsWith("/") ? path.substring(0, path.length() - 1) : path;

			if (!Strings.isNullOrEmpty(path)) {
				sb.append("/");
				sb.append(path);
			}
		}
		return sb.toString();
	}

	public static Integer strToInteger(String string) {
		return Strings.isNullOrEmpty(string) ? null : Integer.parseInt(string);
	}

	public static Long strToLong(String string) {
		return Strings.isNullOrEmpty(string) ? null : Long.parseLong(string);
	}
	
	
	
	
	public static void main(String[] args) {
		System.out.println("a");
		System.out.println("bvb");
	}

}
