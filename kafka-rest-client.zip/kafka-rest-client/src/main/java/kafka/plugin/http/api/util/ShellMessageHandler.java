package kafka.plugin.http.api.util;

public interface ShellMessageHandler {
	void handle(String message) throws InterruptedException;
}
