package kafka.plugin.http.api.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kafka.plugin.http.api.service.impl.KafkaServiceImpl;

public class RegexUtil {
	static String str = "connect1        topic-device-hardware-first    0   86              87              1               connect1_c001-1546917458160-3a52c782-0";
	
	
	public static Matcher match(String regex,String string) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(string);
		return matcher;
	}
	
	
	public static String matchStr(String regex,String string) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(string);
		if(matcher.find()) {
			return matcher.group(1);
		}
		return null;
	}
	
	public static void main(String[] args) {
		String CONSUMER_OFFSET_REGEX = "(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*)";
		String string = "connect1        topic-tsa-first                0   1800450         1800450         0               connect1_m001-1547520071430-51bc4fb7-0";
		Matcher matcher = match(CONSUMER_OFFSET_REGEX, string);
		matcher.find();
		System.out.println(matcher.group(7));
	}
}
