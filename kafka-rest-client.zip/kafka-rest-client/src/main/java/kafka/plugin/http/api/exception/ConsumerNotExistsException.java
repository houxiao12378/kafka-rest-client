package kafka.plugin.http.api.exception;

public class ConsumerNotExistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ConsumerNotExistsException(String message) {
		super(message);
	}

}
