package kafka.plugin.http.api.util;

import java.net.ConnectException;
import java.util.concurrent.TimeUnit;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;

public class ZookeeperUtil {
	/**
	 * 建立一个链接
	 *
	 * @title getConnection
	 * @return CuratorFramework
	 * @throws InterruptedException 
	 * @throws ConnectException 
	 * @auth xiaojian.hou
	 * @date 2018年12月10日
	 */
	public static CuratorFramework getConnection(String connectString,Integer maxWaitTime) throws InterruptedException, ConnectException {
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
		CuratorFramework client = CuratorFrameworkFactory.newClient(connectString, retryPolicy);
		client.start();
		if(!client.blockUntilConnected(maxWaitTime, TimeUnit.MILLISECONDS)){
			throw new ConnectException("链接到Zookeeper失败，无法链接或者链接超时！");
		}
		return client;
	}
	
}
