package kafka.plugin.http.api.domain;

import java.util.List;
import java.util.Map;

public class TopicInfo {
	private String name;
	private Integer partitionCount;
	private Integer replicationFactor;
	private List<Map<String, Object>> configs;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPartitionCount() {
		return partitionCount;
	}

	public void setPartitionCount(Integer partitionCount) {
		this.partitionCount = partitionCount;
	}

	public Integer getReplicationFactor() {
		return replicationFactor;
	}

	public void setReplicationFactor(Integer replicationFactor) {
		this.replicationFactor = replicationFactor;
	}

	public List<Map<String, Object>> getConfigs() {
		return configs;
	}

	public void setConfigs(List<Map<String, Object>> configs) {
		this.configs = configs;
	}

	@Override
	public String toString() {
		return "TopicInfo [name=" + name + ", partitionCount=" + partitionCount + ", replicationFactor="
				+ replicationFactor + ", configs=" + configs + "]";
	}

}
