package kafka.plugin.http.api.web.v1;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kafka.plugin.http.api.common.Response;
import kafka.plugin.http.api.common.ResponseFactory;
import kafka.plugin.http.api.domain.ConsumerOffset;
import kafka.plugin.http.api.domain.TopicInfo;
import kafka.plugin.http.api.service.KafkaService;

@RestController
@RequestMapping("/v1/kafka/")
public class KafkaController {
	
	@Autowired
	KafkaService kafkaService;
	
	
	/**
	 * 获取所有组
	 * @param zookeeper
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/groups", method=RequestMethod.GET) 
    public Response<List<String>> listGroups(@RequestParam("zookeeper") String zookeeper) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("zookeeper", zookeeper);
        return ResponseFactory.success(kafkaService.listGroups(params));
    }
	
	
	/**
	 * 获取组的消费情况
	 * @param zookeeper
	 * @param group
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/groups/{group}", method=RequestMethod.GET) 
    public Response<List<ConsumerOffset>> getGroupConsumerOffset(@RequestParam("zookeeper") String zookeeper,@PathVariable("group") String group) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("zookeeper", zookeeper);
		params.put("group", group);
		return ResponseFactory.success(kafkaService.getGroupConsumerOffset(params));
    }
	
	
	
	/**
	 * 获取组的某个topic消费情况
	 * @param zookeeper
	 * @param group
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/groups/{group}/{topic}", method=RequestMethod.GET) 
    public Response<List<ConsumerOffset>> getTopicConsumerOffset(@RequestParam("zookeeper") String zookeeper,@PathVariable("group") String group,@PathVariable("topic") String topic) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("zookeeper", zookeeper);
		params.put("group", group);
		params.put("topic", topic);
		return ResponseFactory.success(kafkaService.getGroupConsumerOffset(params));
    }
	
	/**
	 * 获取所有topic
	 * @param zookeeper
	 * @param group
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/topics", method=RequestMethod.GET)
    public Response<List<String>> listTopics(@RequestParam("zookeeper") String zookeeper) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("zookeeper", zookeeper);
		return ResponseFactory.success(kafkaService.listTopics(params));
    }
	
	
	/**
	 * 获取topic的描述信息
	 * @param zookeeper
	 * @param topic
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/topics/{topic}", method=RequestMethod.GET) 
    public Response<TopicInfo> describeTopic(@RequestParam("zookeeper") String zookeeper,@PathVariable("topic") String topic) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("zookeeper", zookeeper);
		params.put("topic", topic);
		return ResponseFactory.success(kafkaService.describeTopic(params));
    }
	
	/**
	 * 创建一个topic
	 * @param zookeeper
	 * @param topic
	 * @param partitions
	 * @param replications
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/topics/{topic}/_create", method=RequestMethod.POST) 
    public Response<Object> createTopic(@RequestParam("zookeeper") String zookeeper,@PathVariable("topic") String topic,@RequestParam("partitions") Integer partitions,@RequestParam("replicationFactors") Integer replicationFactors) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("zookeeper", zookeeper);
		params.put("topic", topic);
		params.put("partitions", partitions);
		params.put("replicationFactors", replicationFactors);
		kafkaService.createTopic(params);
		return ResponseFactory.success();
    }
	
	
	/**
	 * 删除指定topic
	 * @param zookeeper
	 * @param topic
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/topics/{topic}", method=RequestMethod.DELETE) 
    public Response<Object> deleteTopic(@RequestParam("zookeeper") String zookeeper,@PathVariable("topic") String topic) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("zookeeper", zookeeper);
		params.put("topic", topic);
		kafkaService.deleteTopic(params);
		return ResponseFactory.success();
    }
	
	/**
	 * 向topic生产一条数据
	 * @param zookeeper
	 * @param topic
	 * @param brokerList
	 * @param message
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/producer/_create", method=RequestMethod.POST) 
    public Response<String> createProducer(@RequestParam("topic") String topic,@RequestParam("brokerList") String brokerList,@RequestParam("timeout") Long timeout) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("brokerList", brokerList);
		params.put("topic", topic);
		params.put("timeout", timeout);
		return ResponseFactory.success(kafkaService.createProducer(params));
    }
	
	/**
	 * 
	 * @param topic
	 * @param brokerList
	 * @param timeout
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/producer/{producerId}/_destory", method=RequestMethod.POST)
    public Response<Object> destoryProducer(@PathVariable("producerId") String producerId) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("producerId", producerId);
		kafkaService.destoryProducer(params);
		return ResponseFactory.success();
    }
	
	
	/**
	 * 向topic生产一条数据
	 * @param zookeeper
	 * @param topic
	 * @param brokerList
	 * @param message
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/producer/{producerId}/_produce", method=RequestMethod.POST) 
    public Response<Object> produce(@PathVariable("producerId") String producerId,@RequestParam("message") String message) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("producerId", producerId);
		params.put("message", message);
		kafkaService.produce(params);
		return ResponseFactory.success();
    }
	
	
	/**
	 *      获取生产日志
	 * @param producerId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/producer/{producerId}/log", method=RequestMethod.GET) 
    public Response<String> producerLog(@PathVariable("producerId") String producerId) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("producerId", producerId);
		return ResponseFactory.success(kafkaService.producerLog(params));
    }
	
	
	
	/**
	 * createConsumer
	 * @param topic
	 * @param zookeeper
	 * @param fromBeginning
	 * @param maxMessages
	 * @param timeout
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/consumer/_create", method=RequestMethod.POST) 
    public Response<String> createConsumer(@RequestParam("topic") String topic,
    		@RequestParam("zookeeper") String zookeeper,
    		@RequestParam("grep") String grep,
    		@RequestParam("fromBeginning") Boolean fromBeginning,
    		@RequestParam(value="maxMessages",required=false) Integer maxMessages,
    		@RequestParam("timeout") Long timeout) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("topic", topic);
		params.put("zookeeper", zookeeper);
		params.put("grep", grep);
		params.put("fromBeginning", fromBeginning);
		params.put("maxMessages", maxMessages);
		params.put("timeout", timeout);
		return ResponseFactory.success(kafkaService.createConsumer(params));
    }
	
	/**
	 * consume
	 * @param consumerId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/consumer/{consumerId}/_consume", method=RequestMethod.POST) 
    public Response<List<String>> consume(@PathVariable("consumerId") String consumerId) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("consumerId", consumerId);
		return ResponseFactory.success(kafkaService.consume(params));
    }
	
	/**
	 * destoryConsumer
	 * 
	 * @param producerId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/consumer/{consumerId}/_destory", method=RequestMethod.POST)
    public Response<Object> destoryConsumer(@PathVariable("consumerId") String consumerId) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("consumerId", consumerId);
		kafkaService.destoryConsumer(params);
		return ResponseFactory.success();
    }
	
	
	/**
	 *      获取消费日志
	 * @param consumerId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/consumer/{consumerId}/log", method=RequestMethod.GET) 
    public Response<String> consumerLog(@PathVariable("consumerId") String consumerId) throws Exception {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("consumerId", consumerId);
		return ResponseFactory.success(kafkaService.consumerLog(params));
    }
	
	
}
