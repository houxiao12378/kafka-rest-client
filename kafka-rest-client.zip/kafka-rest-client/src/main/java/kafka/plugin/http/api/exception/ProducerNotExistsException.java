package kafka.plugin.http.api.exception;

public class ProducerNotExistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ProducerNotExistsException(String message) {
		super(message);
	}

}
