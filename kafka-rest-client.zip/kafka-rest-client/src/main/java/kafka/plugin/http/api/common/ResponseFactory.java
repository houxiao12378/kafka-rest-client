package kafka.plugin.http.api.common;

public class ResponseFactory {
	public static Response<Object> success(){
		return new Response<Object>(RestStatus.SUCCESS.getStatusCode(), null,null);
	}
	
	
	public static <T> Response<T> success(T t){
		return new Response<T>(RestStatus.SUCCESS.getStatusCode(), t,null);
	}
	
	
	public static <T> Response<T> fail(RestStatus status, String message){
		return new Response<T>(status.getStatusCode(), null, message);
	}
}
