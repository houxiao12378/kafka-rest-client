package kafka.plugin.http.api.exception;

public class CreateTopicFailException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CreateTopicFailException(String message) {
		super(message);
	}

}
