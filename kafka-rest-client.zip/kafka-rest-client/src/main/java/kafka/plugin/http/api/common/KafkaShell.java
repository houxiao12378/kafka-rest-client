package kafka.plugin.http.api.common;

public class KafkaShell {
	public static final String KAFKA_CONSUMER_OFFSET_CHECKER = "kafka-consumer-offset-checker.sh";
	public static final String KAFKA_TOPICS = "kafka-topics.sh";
	public static final String KAFKA_CONSOLE_PRODUCER = "kafka-console-producer.sh";
	public static final String KAFKA_CONSOLE_CONSUMER = "kafka-console-consumer.sh";
	
}
