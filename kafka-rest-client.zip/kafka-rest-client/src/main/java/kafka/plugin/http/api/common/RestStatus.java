package kafka.plugin.http.api.common;

public enum RestStatus {
	SUCCESS(0),
	EXCEPTION(100),
	TOPIC_NOT_EXISTS_EXCEPTION(101),
	CREATE_TOPIC_FAIL_EXCEPTION(102),
	DELETE_TOPIC_FAIL_EXCEPTION(103),
	PRODUCER_NOT_EXISTS_EXCEPTION(104),
	CONSUMER_NOT_EXISTS_EXCEPTION(105),
	;
	private Integer statusCode;
	
    RestStatus(Integer statusCode) {
		this.statusCode=statusCode;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
    
    
    
	
}
