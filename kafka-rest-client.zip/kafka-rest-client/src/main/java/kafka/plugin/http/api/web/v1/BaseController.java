package kafka.plugin.http.api.web.v1;

public class BaseController {
	
}
