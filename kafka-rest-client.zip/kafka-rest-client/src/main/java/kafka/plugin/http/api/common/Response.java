package kafka.plugin.http.api.common;

public class Response<T> {
	private Integer status;
	private String message;
	private T result;
	
	
	public Response(Integer status, T result,String message) {
		super();
		this.status = status;
		this.result = result;
		this.message = message;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public T getResult() {
		return result;
	}
	public void setResult(T result) {
		this.result = result;
	}
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "Response [status=" + status + ", message=" + message + ", result=" + result + "]";
	}

	
	
	
	
	
}
