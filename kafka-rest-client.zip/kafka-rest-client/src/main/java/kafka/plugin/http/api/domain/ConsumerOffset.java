package kafka.plugin.http.api.domain;
/**
 * 
 * Kafka消费的偏移量
 * @author Administrator
 *
 */
public class ConsumerOffset {
	private String group;
	private String topic;
	private Integer partitionId;
	private Long offset;
	private Long logSize;
	private Long lag;
	private String owner;
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public Integer getPartitionId() {
		return partitionId;
	}
	public void setPartitionId(Integer partitionId) {
		this.partitionId = partitionId;
	}
	public Long getOffset() {
		return offset;
	}
	public void setOffset(Long offset) {
		this.offset = offset;
	}
	public Long getLogSize() {
		return logSize;
	}
	public void setLogSize(Long logSize) {
		this.logSize = logSize;
	}
	public Long getLag() {
		return lag;
	}
	public void setLag(Long lag) {
		this.lag = lag;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	@Override
	public String toString() {
		return "ConsumerOffset [group=" + group + ", topic=" + topic + ", partitionId=" + partitionId + ", offset="
				+ offset + ", logSize=" + logSize + ", lag=" + lag + ", owner=" + owner + "]";
	}
	
	
	
	
	
}
