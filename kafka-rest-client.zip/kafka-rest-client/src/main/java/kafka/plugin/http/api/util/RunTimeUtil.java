package kafka.plugin.http.api.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kafka.plugin.http.api.common.Constant;
import kafka.plugin.http.api.service.KafkaService;

public class RunTimeUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(RunTimeUtil.class);
	
	
	/**
	 * 运行命令
	 * @param shell
	 * @return
	 * @throws IOException
	 */
	public static String run(String shell) throws IOException {
		LOGGER.info("exec:"+shell);
		Process process = null;
		BufferedReader br = null;
		InputStreamReader reader = null;
		InputStream in = null;
		StringBuilder sb = new StringBuilder();
		try {
			process = createProcess(shell);
			in = process.getInputStream();
			String line;
			reader = new InputStreamReader(in);
			br = new BufferedReader(reader);
			while ((line = br.readLine()) != null) {
				sb.append(line);
				sb.append(Constant.ENTER_CHAR);
			}
		} finally {
			IOUtils.closeQuietly(br);
			IOUtils.closeQuietly(reader);
			IOUtils.closeQuietly(in);
			if(process != null) {
				process.destroy();
			}
		}
		
		
		return sb.toString();

	}
	
	
	/**
	 * 创建进程
	 * @param shell
	 * @return
	 * @throws IOException
	 */
	public static Process createProcess(String shell) throws IOException {
		LOGGER.info("exec:"+shell);
		return Runtime.getRuntime().exec(shell);
	}
	
	/**
	 * 创建进程
	 * @param shell
	 * @return
	 * @throws IOException
	 */
	public static Process createProcess(String[] shells) throws IOException {
		return Runtime.getRuntime().exec(shells);
	}
	
	
	/**
	 * 获取进程执行的错误信息
	 * @param process
	 * @return
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public static void handleErrorMessage(Process process,ShellMessageHandler handler) throws IOException, InterruptedException {
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					InputStream in = process.getErrorStream();
					BufferedReader br = null;
					InputStreamReader reader = null;
					String line;
					reader = new InputStreamReader(in);
					br = new BufferedReader(reader);
					while ((line = br.readLine()) != null) {
						handler.handle(line);
					}
				}catch (IOException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
	}).start();
	}
	
	
	/**
	 * 获取进程执行的错误信息
	 * @param process
	 * @return
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public static void handleInfoMessage(Process process,ShellMessageHandler handler) throws IOException, InterruptedException {
		
		new Thread(new Runnable() {
					
				@Override
				public void run() {
					try {
						InputStream in = process.getInputStream();
						BufferedReader br = null;
						InputStreamReader reader = null;
						String line;
						reader = new InputStreamReader(in);
						br = new BufferedReader(reader);
						while ((line = br.readLine()) != null) {
							handler.handle(line);
						}
					}catch (IOException e) {
						e.printStackTrace();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
		}).start();
	}
}


