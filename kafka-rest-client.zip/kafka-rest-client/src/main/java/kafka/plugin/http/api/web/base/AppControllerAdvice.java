package kafka.plugin.http.api.web.base;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import kafka.plugin.http.api.common.Response;
import kafka.plugin.http.api.common.ResponseFactory;
import kafka.plugin.http.api.common.RestStatus;
import kafka.plugin.http.api.exception.ConsumerNotExistsException;
import kafka.plugin.http.api.exception.CreateTopicFailException;
import kafka.plugin.http.api.exception.DeleteTopicFailException;
import kafka.plugin.http.api.exception.ProducerNotExistsException;
import kafka.plugin.http.api.exception.TopicNotExistsException;

@ControllerAdvice
public class AppControllerAdvice {
	/**
	 * 
	 * @param ex
	 * @return
	 */
    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public Response<Object> errorHandler(Exception ex) {
    	ex.printStackTrace();
        return ResponseFactory.fail(RestStatus.EXCEPTION,ex.getMessage());
    }
    
    
    /**
	 * 
	 * @param ex
	 * @return
	 */
    @ResponseBody
    @ExceptionHandler(value = TopicNotExistsException.class)
    public Response<Object> errorHandler(TopicNotExistsException ex) {
    	ex.printStackTrace();
        return ResponseFactory.fail(RestStatus.TOPIC_NOT_EXISTS_EXCEPTION ,ex.getMessage());
    }
    
    
    /**
	 * 
	 * @param ex
	 * @return
	 */
    @ResponseBody
    @ExceptionHandler(value = CreateTopicFailException.class)
    public Response<Object> errorHandler(CreateTopicFailException ex) {
    	ex.printStackTrace();
        return ResponseFactory.fail(RestStatus.CREATE_TOPIC_FAIL_EXCEPTION ,ex.getMessage());
    }
    
    /**
	 * 
	 * @param ex
	 * @return
	 */
    @ResponseBody
    @ExceptionHandler(value = DeleteTopicFailException.class)
    public Response<Object> errorHandler(DeleteTopicFailException ex) {
    	ex.printStackTrace();
        return ResponseFactory.fail(RestStatus.DELETE_TOPIC_FAIL_EXCEPTION ,ex.getMessage());
    }
    
   /**
    * 
    * @param ex
    * @return
    */
   @ResponseBody
   @ExceptionHandler(value = ProducerNotExistsException.class)
   public Response<Object> errorHandler(ProducerNotExistsException ex) {
   	   ex.printStackTrace();
       return ResponseFactory.fail(RestStatus.PRODUCER_NOT_EXISTS_EXCEPTION ,ex.getMessage());
   }
   
   
   /**
    * 
    * @param ex
    * @return
    */
   @ResponseBody
   @ExceptionHandler(value = ConsumerNotExistsException.class)
   public Response<Object> errorHandler(ConsumerNotExistsException ex) {
   	   ex.printStackTrace();
       return ResponseFactory.fail(RestStatus.CONSUMER_NOT_EXISTS_EXCEPTION ,ex.getMessage());
   }

}