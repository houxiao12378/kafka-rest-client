package kafka.plugin.http.api.util;

public class ObjectUtil {
	
	/**
	 * 根据Object获取字符串
	 * @param o
	 * @return
	 */
	public static String getString(Object o) {
		if(o == null) return null;
		return o.toString();
	}
	
	
	/**
	 * 根据Object获取Integer
	 * @param o
	 * @return
	 */
	public static Integer getInteger(Object o) {
		if(o == null) return null;
		return Integer.parseInt(o.toString());
	}
	
	
	
	/**
	 * 根据Object获取Long
	 * @param o
	 * @return
	 */
	public static Long getLong(Object o) {
		if(o == null) return null;
		return Long.parseLong(o.toString());
	}
	
	/**
	 * 根据Object获取Boolean
	 * @param o
	 * @return
	 */
	public static Boolean getBoolean(Object o) {
		if(o == null) return null;
		return Boolean.parseBoolean(o.toString());
	}
}
