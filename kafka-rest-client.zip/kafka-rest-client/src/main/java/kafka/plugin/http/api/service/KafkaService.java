package kafka.plugin.http.api.service;

import java.util.List;
import java.util.Map;

import kafka.plugin.http.api.domain.ConsumerOffset;
import kafka.plugin.http.api.domain.TopicInfo;

public interface KafkaService {
	
	List<String> listGroups(Map<String, Object> params) throws Exception;

	List<ConsumerOffset> getGroupConsumerOffset(Map<String, Object> params) throws Exception;

	List<String> listTopics(Map<String, Object> params) throws Exception;

	TopicInfo describeTopic(Map<String, Object> params) throws Exception;

	void createTopic(Map<String, Object> params)  throws Exception;

	void deleteTopic(Map<String, Object> params) throws Exception;

	String createProducer(Map<String, Object> params) throws Exception;

	void produce(Map<String, Object> params) throws Exception;

	String producerLog(Map<String, Object> params) throws Exception;

	void destoryProducer(Map<String, Object> params) throws Exception;

	String createConsumer(Map<String, Object> params) throws Exception;

	List<String> consume(Map<String, Object> params) throws Exception;

	void destoryConsumer(Map<String, Object> params)  throws Exception;

	String consumerLog(Map<String, Object> params) throws Exception;
}
