package kafka.plugin.http.api.task;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import kafka.plugin.http.api.domain.Consumer;
import kafka.plugin.http.api.domain.Producer;
import kafka.plugin.http.api.service.KafkaService;
import kafka.plugin.http.api.service.impl.KafkaServiceImpl;

@Component
public class SchedulerTask {

	@Autowired
	KafkaService kafkaService;
	private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerTask.class);

	@Scheduled(fixedDelay = 5 * 60 * 1000)
	private void detectProducer() throws Exception {
		LOGGER.info("正在检测超时的生产者....");
		synchronized (KafkaServiceImpl.PRODUCERS) {
			Map<String, Producer> producers = KafkaServiceImpl.PRODUCERS;
			Producer producer;
			for (Entry<String, Producer> each : producers.entrySet()) {
				producer = each.getValue();
				if (System.currentTimeMillis() > (producer.getCreateTime() + producer.getTimeout())) {
					LOGGER.info("clear producer :"+producer.getId());
					// timeout
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("producerId", producer.getId());
					kafkaService.destoryProducer(params);
				}
			}
		}
		LOGGER.info("检测超时的生产者完成!");
	}

	@Scheduled(fixedDelay = 5 * 60 * 1000)
	private void detectConsumer() throws Exception {
		LOGGER.info("正在检测超时的消费者....");
		Map<String, Consumer> consumers = KafkaServiceImpl.CONSUMERS;
		Consumer consumer;
		for (Entry<String, Consumer> each : consumers.entrySet()) {
			consumer = each.getValue();
			if (System.currentTimeMillis() > (consumer.getCreateTime() + consumer.getTimeout())) {
				LOGGER.info("clear consumer :"+consumer.getId());
				// timeout
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("consumerId", consumer.getId());
				kafkaService.destoryProducer(params);
			}
		}
		LOGGER.info("检测超时的消费者完成!");
	}
}
