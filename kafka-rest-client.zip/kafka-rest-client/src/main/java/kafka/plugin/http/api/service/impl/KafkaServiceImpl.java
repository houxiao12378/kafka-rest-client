package kafka.plugin.http.api.service.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.shaded.com.google.common.base.Strings;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.base.Charsets;

import kafka.plugin.http.api.common.Constant;
import kafka.plugin.http.api.common.KafkaShell;
import kafka.plugin.http.api.domain.Consumer;
import kafka.plugin.http.api.domain.ConsumerOffset;
import kafka.plugin.http.api.domain.Producer;
import kafka.plugin.http.api.domain.TopicInfo;
import kafka.plugin.http.api.exception.ConsumerNotExistsException;
import kafka.plugin.http.api.exception.CreateTopicFailException;
import kafka.plugin.http.api.exception.DeleteTopicFailException;
import kafka.plugin.http.api.exception.ProducerNotExistsException;
import kafka.plugin.http.api.exception.TopicNotExistsException;
import kafka.plugin.http.api.service.KafkaService;
import kafka.plugin.http.api.util.ObjectUtil;
import kafka.plugin.http.api.util.RegexUtil;
import kafka.plugin.http.api.util.RunTimeUtil;
import kafka.plugin.http.api.util.ShellMessageHandler;
import kafka.plugin.http.api.util.StringUtil;
import kafka.plugin.http.api.util.ZookeeperUtil;

@Service
public class KafkaServiceImpl implements KafkaService {
	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaService.class);
	
	public static final Map<String,Producer> PRODUCERS = new ConcurrentHashMap<String, Producer>();
	public static final Map<String,Consumer> CONSUMERS = new ConcurrentHashMap<String, Consumer>();

	private static final String ZK_CONSUMER_GROUP_PATH = "/consumers";
	private static final String ZK_CONSUMER_GROUP_TOPIC_PATH = "/consumers/%s/offsets";
	private static final Integer ZK_MAX_WAIT_TIME = 5000;

	// cmd return value matcher regex
	private static final String CONSUMER_OFFSET_HEADER_REGEX = "Group\\s+Topic\\s+Pid\\s+Offset\\s+logSize\\s+Lag\\s+Owner";
	private static final String CONSUMER_OFFSET_REGEX = "(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*?)\\s+(.*)";
	private static final String DESCRIBE_TOPIC_NAME_REGEX = "Topic:(.+?)\\s+";
	private static final String DESCRIBE_TOPIC_PARTITION_COUNT_REGEX = "PartitionCount:(\\d+?)\\s+";
	private static final String DESCRIBE_TOPIC_REPLICATIONFACTOR_REGEX = "ReplicationFactor:(\\d+?)\\s+";
	private static final String DESCRIBE_TOPIC_CONFIGS_REGEX = "Partition:\\s*(\\d*?)\\s+Leader:\\s*(\\d*?)\\s+Replicas:\\s*(\\d*?)\\s+Isr:\\s*(\\d*)";

	// cmd formatter
	private static final String CONSUMER_TOPIC_OFFSET_CMD_FORMATTER = " --zookeeper %s --group %s --topic %s";
	private static final String CONSUMER_GROUP_OFFSET_CMD_FORMATTER = " --zookeeper %s --group %s";
	private static final String LIST_TOPIC_CMD_FORMATTER = " --zookeeper %s --list";
	private static final String DESCRIBE_TOPIC_CMD_FORMATTER = " --zookeeper %s --describe --topic %s";
	private static final String CREATE_TOPIC_CMD_FORMATTER = " --create --zookeeper %s --topic %s --partition %d --replication-factor %d";
	private static final String DELETE_TOPIC_CMD_FORMATTER = " --delete --zookeeper %s --topic %s";
	private static final String PRODUCER_CMD_FORMATTER = " --broker-list %s --topic %s";
	private static final String CONSUMER_CMD_FORMATTER = " --zookeeper %s  --topic %s ";

	// cmd response message
	private static final String CREATE_TOPIC_SUCCESS_MESSAGE_STARTER = "Created topic";
	private static final String DELETE_TOPIC_SUCCESS_MESSAGE_ENDER = "is marked for deletion.";

	// application.properties
	@Value("${kafka.client.bin.path}")
	private String kafkaClientBinPath;

	@Override
	public List<String> listGroups(Map<String, Object> params) throws Exception {
		CuratorFramework connection = null;
		try {
			String zookeeper = ObjectUtil.getString(params.get("zookeeper"));
			connection = ZookeeperUtil.getConnection(zookeeper, ZK_MAX_WAIT_TIME);
			return connection.getChildren().forPath(ZK_CONSUMER_GROUP_PATH);
		} finally {
			IOUtils.closeQuietly(connection);
		}
	}
	
	
	private List<String> getGroupConsumeTopics(String zookeeper,String group) throws Exception{
		CuratorFramework connection = null;
		try {
			connection = ZookeeperUtil.getConnection(zookeeper, ZK_MAX_WAIT_TIME);
			//TODO:判断路径是否存在
			return connection.getChildren().forPath(String.format(ZK_CONSUMER_GROUP_TOPIC_PATH, group));
		} finally {
			IOUtils.closeQuietly(connection);
		}
	}

	@Override
	public List<ConsumerOffset> getGroupConsumerOffset(Map<String, Object> params) throws Exception {
		String zookeeper = ObjectUtil.getString(params.get("zookeeper"));
		String group = ObjectUtil.getString(params.get("group"));
		String topic = ObjectUtil.getString(params.get("topic"));
		
		List<ConsumerOffset> offsets = new ArrayList<ConsumerOffset>();
		
		if(Strings.isNullOrEmpty(topic)) {
			
			try {
				offsets = getGroupOffset(zookeeper, group);
			} catch (Exception e) {
				// 获取对应的topic
				List<String> topics = getGroupConsumeTopics(zookeeper, group);
				for (String each : topics) {
					List<ConsumerOffset> offsetsTmp = getTopicOffset(zookeeper, group, each);
					if(offsetsTmp != null && !offsetsTmp.isEmpty()) {
						offsets.addAll(offsetsTmp);
					}
				}
			}
		}else {
			List<ConsumerOffset> offsetsTmp = getTopicOffset(zookeeper, group, topic);
			if(offsetsTmp != null && !offsetsTmp.isEmpty()) {
				offsets.addAll(offsetsTmp);
			}
		}
		
		return offsets;
	}
	
	
	private List<ConsumerOffset> getGroupOffset(String zookeeper,String group) throws Exception {
		List<ConsumerOffset> list = new LinkedList<ConsumerOffset>();
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_CONSUMER_OFFSET_CHECKER);
		String cmd = shell + String.format(CONSUMER_GROUP_OFFSET_CMD_FORMATTER, zookeeper, group);
		String result = RunTimeUtil.run(cmd);
		
		if (Strings.isNullOrEmpty(result)) {
			LOGGER.info("get group offset fail");
			throw new Exception("get group offset fail");
		}
		
		String[] rows = result.split(Constant.ENTER_CHAR);
		ConsumerOffset offset;
		Matcher matcher;
		for (int i = 0; i < rows.length; i++) {
			if (i != 0) {
				matcher = RegexUtil.match(CONSUMER_OFFSET_REGEX, rows[i]);
				if (matcher.find()) {
					offset = new ConsumerOffset();
					offset.setGroup(matcher.group(1));
					offset.setTopic(matcher.group(2));
					offset.setPartitionId(StringUtil.strToInteger(matcher.group(3)));
					offset.setOffset(StringUtil.strToLong(matcher.group(4)));
					offset.setLogSize(StringUtil.strToLong(matcher.group(5)));
					offset.setLag(StringUtil.strToLong(matcher.group(6)));
					offset.setOwner(matcher.group(7));
					list.add(offset);
				}
			}else {
				if(!Strings.isNullOrEmpty(rows[i]) && !rows[i].matches(CONSUMER_OFFSET_HEADER_REGEX)) {
					LOGGER.info("get group offset fail,"+rows[i]);
					throw new Exception("get group offset fail,"+rows[i]);
				}
			}
		}
		return list;
	}

	
	private List<ConsumerOffset> getTopicOffset(String zookeeper,String group,String topic) throws IOException {
		List<ConsumerOffset> list = new LinkedList<ConsumerOffset>();
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_CONSUMER_OFFSET_CHECKER);
		String cmd = shell + String.format(CONSUMER_TOPIC_OFFSET_CMD_FORMATTER, zookeeper, group, topic);
		String result = RunTimeUtil.run(cmd);
		
		if (!Strings.isNullOrEmpty(result)) {
			String[] rows = result.split(Constant.ENTER_CHAR);
			ConsumerOffset offset;
			Matcher matcher;
			for (int i = 0; i < rows.length; i++) {
				if (i != 0) {
					matcher = RegexUtil.match(CONSUMER_OFFSET_REGEX, rows[i]);
					if (matcher.find()) {
						if (Strings.isNullOrEmpty(topic) || topic.equals(matcher.group(2))) {
							offset = new ConsumerOffset();
							offset.setGroup(matcher.group(1));
							offset.setTopic(matcher.group(2));
							offset.setPartitionId(StringUtil.strToInteger(matcher.group(3)));
							offset.setOffset(StringUtil.strToLong(matcher.group(4)));
							offset.setLogSize(StringUtil.strToLong(matcher.group(5)));
							offset.setLag(StringUtil.strToLong(matcher.group(6)));
							offset.setOwner(matcher.group(7));
							list.add(offset);
						}
					}

				}
			}
		}
		return list;
	}

	@Override
	public List<String> listTopics(Map<String, Object> params) throws Exception {
		String zookeeper = ObjectUtil.getString(params.get("zookeeper"));
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_TOPICS);
		String cmd = shell + String.format(LIST_TOPIC_CMD_FORMATTER, zookeeper);
		String result = RunTimeUtil.run(cmd);
		List<String> topics = new LinkedList<String>();
		if (!Strings.isNullOrEmpty(result)) {
			String[] rows = result.split(Constant.ENTER_CHAR);
			for (int i = 0; i < rows.length; i++) {
				topics.add(rows[i]);
			}
		}
		return topics;
	}

	@Override
	public TopicInfo describeTopic(Map<String, Object> params) throws Exception {
		String zookeeper = ObjectUtil.getString(params.get("zookeeper"));
		String topic = ObjectUtil.getString(params.get("topic"));
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_TOPICS);
		String cmd = shell + String.format(DESCRIBE_TOPIC_CMD_FORMATTER, zookeeper, topic);
		String result = RunTimeUtil.run(cmd);

		TopicInfo topicInfo = new TopicInfo();
		List<Map<String, Object>> configs = new LinkedList<Map<String, Object>>();
		topicInfo.setConfigs(configs);
		Map<String, Object> config;
		if (Strings.isNullOrEmpty(result)) {
			throw new TopicNotExistsException("topic " + topic + " is not exist!");
		}

		String[] rows = result.split(Constant.ENTER_CHAR);
		for (int i = 0; i < rows.length; i++) {
			if (i == 0) {
				// get base info
				topicInfo.setName(RegexUtil.matchStr(DESCRIBE_TOPIC_NAME_REGEX, rows[i]));
				topicInfo.setPartitionCount(
						StringUtil.strToInteger(RegexUtil.matchStr(DESCRIBE_TOPIC_PARTITION_COUNT_REGEX, rows[i])));
				topicInfo.setReplicationFactor(
						StringUtil.strToInteger(RegexUtil.matchStr(DESCRIBE_TOPIC_REPLICATIONFACTOR_REGEX, rows[i])));
			} else {
				// get configs
				Matcher matcher = RegexUtil.match(DESCRIBE_TOPIC_CONFIGS_REGEX, rows[i]);
				config = new HashMap<String, Object>();
				if (matcher.find()) {
					config.put("partition", matcher.group(1));
					config.put("leader", matcher.group(2));
					config.put("replicas", matcher.group(3));
					config.put("isr", matcher.group(4));
					configs.add(config);
				}
			}
		}
		return topicInfo;
	}

	@Override
	public void createTopic(Map<String, Object> params) throws Exception {
		String zookeeper = ObjectUtil.getString(params.get("zookeeper"));
		String topic = ObjectUtil.getString(params.get("topic"));
		Integer partitions = ObjectUtil.getInteger(params.get("partitions"));
		Integer replicationFactors = ObjectUtil.getInteger(params.get("replicationFactors"));
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_TOPICS);
		String cmd = shell
				+ String.format(CREATE_TOPIC_CMD_FORMATTER, zookeeper, topic, partitions, replicationFactors);
		String result = RunTimeUtil.run(cmd);
		if (!Strings.isNullOrEmpty(result)) {
			String responseMessage = result.split(Constant.ENTER_CHAR)[0];
			if (!responseMessage.startsWith(CREATE_TOPIC_SUCCESS_MESSAGE_STARTER)) {
				throw new CreateTopicFailException(responseMessage);
			}
		}
	}

	@Override
	public void deleteTopic(Map<String, Object> params) throws Exception {
		String zookeeper = ObjectUtil.getString(params.get("zookeeper"));
		String topic = ObjectUtil.getString(params.get("topic"));
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_TOPICS);
		String cmd = shell + String.format(DELETE_TOPIC_CMD_FORMATTER, zookeeper, topic);
		String result = RunTimeUtil.run(cmd);
		if (!Strings.isNullOrEmpty(result)) {
			String responseMessage = result.split(Constant.ENTER_CHAR)[0];
			if (!responseMessage.endsWith(DELETE_TOPIC_SUCCESS_MESSAGE_ENDER)) {
				throw new DeleteTopicFailException(responseMessage);
			}
		}
	}

	@Override
	public String createProducer(Map<String, Object> params) throws Exception {
		String topic = ObjectUtil.getString(params.get("topic"));
		String brokerList = ObjectUtil.getString(params.get("brokerList"));
		Long timeout = ObjectUtil.getLong(params.get("timeout"));
		
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_CONSOLE_PRODUCER);
		String cmd = shell + String.format(PRODUCER_CMD_FORMATTER, brokerList, topic);
		Process process = RunTimeUtil.createProcess(cmd);
		
		
		final Producer producer = new Producer();
		producer.setId(UUID.randomUUID().toString());
		producer.setCreateTime(System.currentTimeMillis());
		producer.setTimeout(timeout);
		producer.setProcess(process);
		PRODUCERS.put(producer.getId(), producer);
		
		
		// 接收处理控制台错误信息
		RunTimeUtil.handleErrorMessage(process, new ShellMessageHandler() {
			@Override
			public void handle(String message) throws InterruptedException {
				producer.getConsoleMessages().put(message);
			}
		});
		
		
		// 接收处理控制台INFO信息
		RunTimeUtil.handleInfoMessage(process, new ShellMessageHandler() {
			@Override
			public void handle(String message) throws InterruptedException {
				producer.getConsoleMessages().put(message);
			}
		});
		
		return producer.getId();
		
	}

	@Override
	public void produce(Map<String, Object> params) throws Exception {
		synchronized (PRODUCERS) {
			String producerId = ObjectUtil.getString(params.get("producerId"));
			String message = ObjectUtil.getString(params.get("message"));
			Producer producer = PRODUCERS.get(producerId);
			if(producer == null) {
				throw new ProducerNotExistsException("can not find the producer id!");
			}
			
			OutputStream output = producer.getProcess().getOutputStream();
			output.write((message+Constant.ENTER_CHAR).getBytes(Charsets.UTF_8));
			output.flush();
		}
		
	}

	@Override
	public String producerLog(Map<String, Object> params) throws Exception {
		synchronized (PRODUCERS) {
			String producerId = ObjectUtil.getString(params.get("producerId"));
			Producer producer = PRODUCERS.get(producerId);
			if(producer == null) {
				throw new ProducerNotExistsException("can not find the producer id!");
			}
			
			StringBuilder sb = new StringBuilder();
			while(!producer.getConsoleMessages().isEmpty()) {
				sb.append(producer.getConsoleMessages().take());
				sb.append(Constant.ENTER_CHAR);
			}
		
			return sb.toString();
		}
		
	}

	@Override
	public void destoryProducer(Map<String, Object> params) throws Exception {
		synchronized (PRODUCERS) {
			String producerId = ObjectUtil.getString(params.get("producerId"));
			Producer producer = PRODUCERS.get(producerId);
			if(producer == null) {
				throw new Exception("can not find the producer id!");
			}
			Process process =  producer.getProcess();
			if(process != null && process.isAlive()) {
				process.destroy();
			}
			
			producer.getConsoleMessages().clear();
			
			PRODUCERS.remove(producerId);
		}
	}

	@Override
	public String createConsumer(Map<String, Object> params) throws Exception {
		String topic = ObjectUtil.getString(params.get("topic"));
		String zookeeper = ObjectUtil.getString(params.get("zookeeper"));
		String grep = ObjectUtil.getString(params.get("grep"));
		Boolean fromBeginning = ObjectUtil.getBoolean(params.get("fromBeginning"));
		Integer maxMessages = ObjectUtil.getInteger(params.get("maxMessages"));
		Long timeout = ObjectUtil.getLong(params.get("timeout"));
		
		
		String shell = StringUtil.joinPath(kafkaClientBinPath, KafkaShell.KAFKA_CONSOLE_CONSUMER);
		String formatter = CONSUMER_CMD_FORMATTER + (fromBeginning?" --from-beginning":"") + (maxMessages==null?"":String.format(" --max-messages %d", maxMessages))+ (Strings.isNullOrEmpty(grep)?"":String.format(" |grep '%s'", grep));
		
		String cmd = shell + String.format(formatter, zookeeper, topic);
		
		
		String[] cmds = {"sh","-c",cmd};
		Process process = RunTimeUtil.createProcess(cmds);
		
		
		final Consumer consumer = new Consumer();
		consumer.setId(UUID.randomUUID().toString());
		consumer.setCreateTime(System.currentTimeMillis());
		consumer.setTimeout(timeout);
		consumer.setProcess(process);
		CONSUMERS.put(consumer.getId(), consumer);
		
		
		// 接收处理控制台错误信息
		RunTimeUtil.handleErrorMessage(process, new ShellMessageHandler() {
			@Override
			public void handle(String message) throws InterruptedException {
				consumer.getConsoleMessages().put(message);
			}
		});
		
		
		// 接收处理控制台INFO信息
		RunTimeUtil.handleInfoMessage(process, new ShellMessageHandler() {
			@Override
			public void handle(String message) throws InterruptedException {
				consumer.getMessages().put(message);
			}
		});
		
		return consumer.getId();
		
	}

	@Override
	public List<String> consume(Map<String, Object> params) throws Exception {
		synchronized (CONSUMERS) {
			String consumerId = ObjectUtil.getString(params.get("consumerId"));
			Consumer consumer = CONSUMERS.get(consumerId);
			if(consumer == null) {
				throw new ConsumerNotExistsException("can not find the consumer id!");
			}
			
			List<String> messages = new LinkedList<String>();
			while(!consumer.getMessages().isEmpty() && messages.size()<10) {
				messages.add(consumer.getMessages().take());
			}
			return messages;
		}
	}

	@Override
	public void destoryConsumer(Map<String, Object> params) throws Exception {
		synchronized (CONSUMERS) {
			String consumerId = ObjectUtil.getString(params.get("consumerId"));
			Consumer consumer = CONSUMERS.get(consumerId);
			if(consumer == null) {
				throw new ConsumerNotExistsException("can not find the consumer id!");
			}
			Process process =  consumer.getProcess();
			if(process != null && process.isAlive()) {
				process.destroy();
			}
			
			consumer.getConsoleMessages().clear();
			
			consumer.getMessages().clear();
			
			CONSUMERS.remove(consumerId);
		}
		
	}

	@Override
	public String consumerLog(Map<String, Object> params) throws Exception {
		synchronized (CONSUMERS) {
			String consumerId = ObjectUtil.getString(params.get("consumerId"));
			Consumer consumer = CONSUMERS.get(consumerId);
			if(consumer == null) {
				throw new ConsumerNotExistsException("can not find the consumer id!");
			}
			
			StringBuilder sb = new StringBuilder();
			while(!consumer.getConsoleMessages().isEmpty()) {
				sb.append(consumer.getConsoleMessages().take());
				sb.append(Constant.ENTER_CHAR);
			}
		
			return sb.toString();
		}
		
	}

}
