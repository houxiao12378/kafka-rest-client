package kafka.plugin.http.api.exception;

public class DeleteTopicFailException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DeleteTopicFailException(String message) {
		super(message);
	}

}
