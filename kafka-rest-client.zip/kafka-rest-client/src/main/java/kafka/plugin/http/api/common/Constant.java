package kafka.plugin.http.api.common;

public class Constant {
	public static final String ENTER_CHAR = "\n"; 
}
